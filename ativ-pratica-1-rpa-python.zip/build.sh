#!/bin/bash

zip -r "ativ-pratica-1-rpa-python.zip" * -x "ativ-pratica-1-rpa-python.zip"